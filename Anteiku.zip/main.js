
App.onObjectTouched.Add(function (sender, x, y, tileID, obj) {
    if (obj !== null && obj.type == ObjectEffectType.INTERACTION_WITH_ZEPSCRIPTS) {
        let id = parseInt(obj.param1);
        handleInteraction(sender, id);
    }
});

let heldItem = null;
let counterItems = [];
let currentDish = null;
let sales = 0;
let gameStarted = false;
let gameTimer = 120;
let countdown = 3;
let countdownRunning = false;
let gameTimeLeft = 0;

const ingredients = {
    7: '면', 8: '춘장', 9: '양파',
    10: '고기', 11: '화유', 12: '육수'
};

const recipes = {
    jjajang: [7, 8, 9, 10],
    jjamppong: [7, 9, 10, 11, 12]
};

const tablePositions = [
    {x: 3, y: 16},
    {x: 10, y: 16},
    {x: 18, y: 16},
    {x: 24, y: 16},
    {x: 3, y: 21},
    {x: 10, y: 21}
];

function handleInteraction(player, id) {
    if (!gameStarted && id === 0 && !countdownRunning) {
        App.sayToAll("게임 시작 버튼이 눌렸습니다.", 0);
        startCountdown();
        return;
    }

    if (id === 99) {
        App.sayToAll("게임 강제 종료 버튼이 눌렸습니다.", 0);
        forceEndGame();
        return;
    }

    if (!gameStarted) return;

    if (id >= 7 && id <= 12) {
        if (heldItem == null) {
            heldItem = id;
            App.sayToAll(`${ingredients[id]}을(를) 집었습니다.`, 0);
            App.showCenterLabel(`${ingredients[id]}을(를) 집었습니다.`, 0xFFFFFF, 20);
        } else {
            App.showCenterLabel(`이미 ${ingredients[heldItem]}을(를) 들고 있어요.`, 0xFF5555, 20);
        }
    } else if (id === 13) {
        if (heldItem !== null) {
            if (counterItems.includes(heldItem)) {
                App.sayToAll(`중복된 재료: ${ingredients[heldItem]} → 조리대 초기화됨`, 0);
                App.showCenterLabel(`중복된 재료입니다. 조리대 초기화됨.`, 0xFF4444, 20);
                counterItems = [];
                heldItem = null;
                return;
            }

            counterItems.push(heldItem);

            if (counterItems.length > 5) {
                counterItems.shift();
            }

            const has = (n) => counterItems.includes(n);
            if ((has(8) && has(11)) || (has(8) && has(12))) {
                App.sayToAll("화유+춘장 또는 육수+춘장 조합 감지됨 → 조리대 초기화", 0);
                App.showCenterLabel(`화유+춘장 또는 육수+춘장 조합은 불가능합니다. 조리대 초기화됨.`, 0xFF4444, 20);
                counterItems = [];
                heldItem = null;
                return;
            }

            const displayItems = counterItems.map(i => ingredients[i]).join(', ');
            App.sayToAll(`${ingredients[heldItem]} 추가됨 → 현재 조리대: ${displayItems}`, 0);
            App.showCenterLabel(`${ingredients[heldItem]}을 조리대에 올렸습니다.\n현재 재료: ${displayItems}`, 0xFFFFFF, 20);
            heldItem = null;

            if (counterItems.length >= 4) {
                checkRecipe();
            }
        } else if (currentDish !== null) {
            serveDish();
        } else {
            App.showCenterLabel("들고 있는 재료가 없어요.", 0xFF8888, 20);
        }
    }
}

function startCountdown() {
    countdown = 3;
    countdownRunning = true;
    App.showCenterLabel(`게임이 시작됩니다... ${countdown}`, 0x00FF00, 100);
}

let lastTime = Date.now();

App.onUpdate.Add(function () {
    let now = Date.now();
    let delta = (now - lastTime) / 1000.0;
    lastTime = now;

    if (countdownRunning) {
        countdown -= delta;
        if (countdown <= 0) {
            countdownRunning = false;
            startGame();
        } else {
            App.showCenterLabel(`게임이 시작됩니다... ${Math.ceil(countdown)}`, 0x00FF00, 100);
        }
    }

    if (gameStarted) {
        gameTimeLeft -= delta;
        if (Math.floor(gameTimeLeft) !== Math.floor(gameTimeLeft + delta)) {
            App.showCenterLabel(`남은 시간: ${Math.max(0, Math.ceil(gameTimeLeft))}초\n총 매출: ${sales}원`, 0x00FF00, 60);
        }

        if (gameTimeLeft <= 0) {
            endGame();
        }
    }
});

function startGame() {
    gameStarted = true;
    gameTimeLeft = gameTimer;
    sales = 0;
    App.sayToAll("게임이 시작되었습니다!", 0);
    App.showCenterLabel("게임 시작!", 0x00FF00, 100);
}

function spawnDishObject(objId) {
    const randomIndex = Math.floor(Math.random() * tablePositions.length);
    const pos = tablePositions[randomIndex];
    const spawned = App.spawnObject(objId.toString(), pos.x, pos.y, 1);
    setTimeout(() => {
        App.removeObject(spawned);
    }, 5000);
}

function checkRecipe() {
    let sorted = counterItems.slice().sort((a, b) => a - b).join();
    let jjajang = recipes.jjajang.slice().sort((a, b) => a - b).join();
    let jjamppong = recipes.jjamppong.slice().sort((a, b) => a - b).join();

    if (sorted === jjajang) {
        currentDish = '짜장면';
        sales += 9000;
        counterItems = [];
        App.sayToAll("짜장면이 완성되었습니다!", 0);
        App.showCenterLabel(`짜장면이 완성되었습니다! +9000원\n총 매출: ${sales}원`, 0xFFFF00, 100);
        spawnDishObject(14); // 짜장 오브젝트
    } else if (sorted === jjamppong) {
        currentDish = '짬뽕';
        sales += 9000;
        counterItems = [];
        App.sayToAll("짬뽕이 완성되었습니다!", 0);
        App.showCenterLabel(`짬뽕이 완성되었습니다! +9000원\n총 매출: ${sales}원`, 0xFFFF00, 100);
        spawnDishObject(15); // 짬뽕 오브젝트
    }
}

function serveDish() {
    if (currentDish !== null) {
        App.sayToAll(`${currentDish} 서빙 완료`, 0);
        App.showCenterLabel(`${currentDish} 서빙 완료!\n총 매출: ${sales}원`, 0x00FFFF, 100);
        currentDish = null;
    }
}

function endGame() {
    App.sayToAll(`게임 종료! 총 매출: ${sales}원`, 0);
    gameStarted = false;
    heldItem = null;
    counterItems = [];
    currentDish = null;
    App.showCenterLabel(`게임 종료! 총 매출: ${sales}원`, 0xFFAA00, 150);
}

function forceEndGame() {
    if (gameStarted) {
        App.sayToAll("게임이 강제 종료되었습니다.", 0);
        endGame();
    } else {
        App.showCenterLabel("게임이 실행 중이 아닙니다.", 0x888888, 100);
    }
}
